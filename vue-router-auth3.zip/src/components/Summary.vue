<template>
  <div class = "big-board">
    <h1> Hello, This is Summary Page </h1>
  </div>

</template>

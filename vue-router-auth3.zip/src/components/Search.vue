<template>
  <h3><center>This is Search Page</center></h3>
</template>

module.exports = {
    'secret': 'supersecret'
};
